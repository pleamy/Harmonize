# My Starred Items

This is a demo app that shows how to retrieve the starred items for a Spotify User. 

The app is online at [My Starred Items](http://static.echonest.com/MyStarredItems)

